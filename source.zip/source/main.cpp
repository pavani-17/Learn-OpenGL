#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

#include <stdio.h>

const char *vertexShaderSource ="#version 330 core\n"
    "layout (location = 0) in vec3 aPos;\n"
    "layout (location = 1) in vec3 aColor;\n"
   //  "layout (location = 1) in vec2 aTexCoord; \n"
    "out vec3 ourColor;\n"
    "out vec2 TexCoord; \n"
    "uniform mat4 model; \n"
    "uniform mat4 view; \n"
    "uniform mat4 projection; \n"
    "void main()\n"
    "{\n"
    "   gl_Position = projection * view * model * vec4(aPos, 1.0f);\n"
    "   ourColor = aColor;\n"
   //  "   TexCoord = aTexCoord; \n"
    "}\0";

const char *fragmentShaderSource = "#version 330 core\n"
    "out vec4 FragColor;\n"
    "in vec3 ourColor;\n"
   //  "in vec2 TexCoord; \n"
    "uniform sampler2D texture1; \n"
    "uniform sampler2D texture2; \n"
    "void main()\n"
    "{\n"
    "       FragColor = vec4(ourColor.x, ourColor.y, ourColor.z, 1.0f);\n"
    "}\n\0";

const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

glm::vec3 direction;
float yaw = -90.0f;
float pitch = 0.0f;

void processInput(GLFWwindow *window)
{
   const float cameraSpeed = 0.05f;
   const float sensitivity = 1.0f;
   if(glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
      cameraPos.y += cameraSpeed;
   if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
      cameraPos.y -= cameraSpeed;
   if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
      cameraPos.x -= cameraSpeed;
   if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
      cameraPos.x += cameraSpeed;
   if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS)
      cameraPos.z += cameraSpeed;
   if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS)
      cameraPos.z -= cameraSpeed;

   if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS)
      yaw += sensitivity;
   if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS)
      yaw -= sensitivity;   
   if (glfwGetKey(window, GLFW_KEY_T) == GLFW_PRESS)
      pitch += sensitivity;
   if (glfwGetKey(window, GLFW_KEY_G) == GLFW_PRESS)
      pitch -= sensitivity;  

   if(glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
   {
      glfwSetWindowShouldClose(window, true);
   }
   direction.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
   direction.y = sin(glm::radians(pitch));
   direction.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));

   cameraFront = glm::normalize(direction);

}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

namespace {
   void errorCallback(int error, const char* description) {
      fprintf(stderr, "GLFW error %d: %s\n", error, description);
   }

   GLFWwindow* initialize() {
      int glfwInitRes = glfwInit();
      if (!glfwInitRes) {
         fprintf(stderr, "Unable to initialize GLFW\n");
         return nullptr;
      }

      glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
      glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
      glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
      // glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

      GLFWwindow* window = glfwCreateWindow(800, 600, "InitGL", nullptr, nullptr);
      if (!window) {
         fprintf(stderr, "Unable to create GLFW window\n");
         glfwTerminate();
         return nullptr;
      }

      glfwMakeContextCurrent(window);
      glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

      int gladInitRes = gladLoadGL();
      if (!gladInitRes) {
         fprintf(stderr, "Unable to initialize glad\n");
         glfwDestroyWindow(window);
         glfwTerminate();
         return nullptr;
      }

      return window;
   }
}

int main(int argc, char* argv[]) {
   glfwSetErrorCallback(errorCallback);

   GLFWwindow* window = initialize();
   if (!window) {
      return 0;
   }

   unsigned int vertexShader;
   vertexShader = glCreateShader(GL_VERTEX_SHADER);
   glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
   glCompileShader(vertexShader);

   int success;
   char infoLog[512];
   glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
   if(!success)
   {
      glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
      fprintf(stderr, "Unable to Compile Vertex Shader\n");
      return 0;
   }

   unsigned int fragmentShader;
   fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
   glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
   glCompileShader(fragmentShader);
   glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
   if(!success)
   {
      glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
      fprintf(stderr, "Unable to Compile Fragment Shader\n");
      return 0;
   }

   unsigned int shaderProgram;
   shaderProgram = glCreateProgram();

   glAttachShader(shaderProgram, vertexShader);
   glAttachShader(shaderProgram, fragmentShader);
   glLinkProgram(shaderProgram);

   glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
   if(!success)
   {
      glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
      fprintf(stderr, "Unable to Link Shaders\n");
      return 0;
   }

   glDeleteShader(vertexShader);
   glDeleteShader(fragmentShader);


   // float vertices[] = {
   //       1.0f,  0.0f,  0.0f,  0.3f, 0.4f, 0.5f,
   //       0.5f,  0.86f, 0.0f,  0.2f, 0.4f, 0.3f,
   //       0.0f,  0.0f,  1.0f,  1.0f, 1.0f, 0.0f,
         
   //       1.0f,  0.0f,  0.0f,  0.3f, 0.4f, 0.5f,
   //       0.5f,  0.86f, 0.0f,  0.2f, 0.4f, 0.3f,
   //       0.0f,  0.0f,  -1.0f, 0.0f, 1.0f, 1.0f,

   //      -0.5f,  0.86f, 0.0f,  1.0f, 0.0f, 0.0f,
   //       0.5f,  0.86f, 0.0f,  0.2f, 0.4f, 0.3f,
   //       0.0f,  0.0f,  1.0f,  1.0f, 1.0f, 0.0f,

   //       -0.5f,  0.86f, 0.0f,  1.0f, 0.0f, 0.0f,
   //       0.5f,  0.86f, 0.0f,  0.2f, 0.4f, 0.3f,
   //       0.0f,  0.0f,  -1.0f, 0.0f, 1.0f, 1.0f,

   //      -0.5f,  0.86f, 0.0f,  1.0f, 0.0f, 0.0f,
   //      -1.0f,  0.0f,   0.0f,  0.0f, 1.0f, 0.0f,
   //       0.0f,  0.0f,  1.0f,  1.0f, 1.0f, 0.0f,

   //      -0.5f,  0.86f, 0.0f,  1.0f, 0.0f, 0.0f,
   //      -1.0f,  0.0f,   0.0f,  0.0f, 1.0f, 0.0f,
   //       0.0f,  0.0f,  -1.0f, 0.0f, 1.0f, 1.0f,

   //      -1.0f,  0.0f,   0.0f,  0.0f, 1.0f, 0.0f,
   //      -0.5f, -0.86f, 0.0f,  0.0f, 0.0f, 1.0f,
   //       0.0f,  0.0f,  1.0f,  1.0f, 1.0f, 0.0f,

   //       -1.0f,  0.0f,   0.0f,  0.0f, 1.0f, 0.0f,
   //      -0.5f, -0.86f, 0.0f,  0.0f, 0.0f, 1.0f,
   //       0.0f,  0.0f,  -1.0f, 0.0f, 1.0f, 1.0f,

   //      -0.5f, -0.86f, 0.0f,  0.0f, 0.0f, 1.0f,
   //       0.5f, -0.86f, 0.0f,  0.1f, 0.5f, 0.9f,
   //       0.0f,  0.0f,  1.0f,  1.0f, 1.0f, 0.0f,

   //       -0.5f, -0.86f, 0.0f,  0.0f, 0.0f, 1.0f,
   //       0.5f, -0.86f, 0.0f,  0.1f, 0.5f, 0.9f,
   //       0.0f,  0.0f,  -1.0f, 0.0f, 1.0f, 1.0f,

   //       0.5f, -0.86f, 0.0f,  0.1f, 0.5f, 0.9f,
   //       1.0f,  0.0f,  0.0f,  0.3f, 0.4f, 0.5f,
   //       0.0f,  0.0f,  1.0f,  1.0f, 1.0f, 0.0f,

   //       0.5f, -0.86f, 0.0f,  0.1f, 0.5f, 0.9f,
   //       1.0f,  0.0f,  0.0f,  0.3f, 0.4f, 0.5f,
   //       0.0f,  0.0f,  -1.0f, 0.0f, 1.0f, 1.0f,
   //  };

//     float vertices[] = {
//     -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,
//     0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,
//     0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f,
//     0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f,
//     -0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 0.0f,
//     -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,

//     -0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 1.0f,
//     0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 1.0f,
//     0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.5f,
//    0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.5f,
//     -0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 0.3f,
//    -0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 1.0f,

//     -0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 0.3f,
//    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 0.0f,
//     -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,
//     -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,
//     -0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 1.0f,
//     -0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 0.3f,

//     0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.5f,
//     0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f,
//     0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,
//     0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,
//     0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 1.0f,
//     0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.5f,
   
//    // plane 2
//     -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,
//     0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,
//     0.0f, -1.0f, 0.0f, 0.3f, 0.4f, 0.5f,

//     -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,
//     -0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 1.0f,
//     0.0f, -1.0f, 0.0f, 0.3f, 0.4f, 0.5f,    

//     0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 1.0f,
//    -0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 1.0f,
//     0.0f, -1.0f, 0.0f, 0.3f, 0.4f, 0.5f,

//      0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,
//      0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 1.0f,
//      0.0f, -1.0f, 0.0f, 0.3f, 0.4f, 0.5f,


//    // Plane1
//     -0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 0.0f,
//     0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f,
//     0.0f,  1.0f, 0.0f, 0.5f, 0.4f, 0.3f,

//     0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.5f,
//     -0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 0.3f,
//     0.0f,  1.0f, 0.0f, 0.5f, 0.4f, 0.3f,

//     -0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 0.3f,
//      -0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 0.0f,
//      0.0f,  1.0f, 0.0f, 0.5f, 0.4f, 0.3f,

//      0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.5f,
//      0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f,
//      0.0f,  1.0f, 0.0f, 0.5f, 0.4f, 0.3f,


// };


float vertices[] = {
   1.0f, 0.25f, 0.0f, 1.0f, 0.0f, 0.0f,
   0.809f, 0.25f, 0.58f, 0.0f, 0.0f, 1.0f,
   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,

   0.809f, 0.25f, 0.58f, 0.0f, 0.0f, 1.0f,
   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   0.309f, 0.25f, 0.95f, 1.0f, 1.0f, 0.0f,

   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   0.309f, 0.25f, 0.95f, 1.0f, 1.0f, 0.0f,
   -0.309f, 0.25f, 0.95f, 0.0f, 1.0f, 1.0f,

   -0.309f, 0.25f, 0.95f, 0.0f, 1.0f, 1.0f,
   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   -0.809f, 0.25f, 0.58f, 0.25f, 0.4f, 0.7f,

   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   -0.809f, 0.25f, 0.58f, 0.25f, 0.4f, 0.7f,
   -1.0f, 0.25f, 0.0f, 0.0f, 0.25f, 0.25f,
   
   -1.0f, 0.25f, 0.0f, 0.0f, 0.25f, 0.25f,
   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   -0.809f, 0.25f, -0.58f, 0.6f, 0.3f, 0.25f,

   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   -0.809f, 0.25f, -0.58f, 0.6f, 0.3f, 0.25f,
   -0.309f, 0.25f, -0.95f, 0.25f, 0.6f, 1.0f,

   -0.309f, 0.25f, -0.95f, 0.25f, 0.6f, 1.0f,
   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   0.309f, 0.25f, -0.95f, 0.3f, 0.4f, 0.25f,

   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   0.309f, 0.25f, -0.95f, 0.3f, 0.4f, 0.25f,
   0.809f, 0.25f, -0.58f, 0.2f, 0.25f, 0.8f,

   0.809f, 0.25f, -0.58f, 0.2f, 0.25f, 0.8f,
   0.0f, 0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   1.0f, 0.25f, 0.0f, 1.0f, 0.0f, 0.0f,

   // negative plane

   1.0f, -0.25f, 0.0f, 1.0f, 0.0f, 0.0f,
   0.809f, -0.25f, 0.58f, 0.0f, 0.0f, 1.0f,
   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,

   0.809f, -0.25f, 0.58f, 0.0f, 0.0f, 1.0f,
   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   0.309f, -0.25f, 0.95f, 1.0f, 1.0f, 0.0f,

   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   0.309f, -0.25f, 0.95f, 1.0f, 1.0f, 0.0f,
   -0.309f, -0.25f, 0.95f, 0.0f, 1.0f, 1.0f,

   -0.309f, -0.25f, 0.95f, 0.0f, 1.0f, 1.0f,
   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   -0.809f, -0.25f, 0.58f, 0.25f, 0.4f, 0.7f,

   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   -0.809f, -0.25f, 0.58f, 0.25f, 0.4f, 0.7f,
   -1.0f, -0.25f, 0.0f, 0.0f, 0.25f, 0.25f,
   
   -1.0f, -0.25f, 0.0f, 0.0f, 0.25f, 0.25f,
   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   -0.809f, -0.25f, -0.58f, 0.6f, 0.3f, 0.25f,

   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   -0.809f, -0.25f, -0.58f, 0.6f, 0.3f, 0.25f,
   -0.309f, -0.25f, -0.95f, 0.25f, 0.6f, 1.0f,

   -0.309f, -0.25f, -0.95f, 0.25f, 0.6f, 1.0f,
   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   0.309f, -0.25f, -0.95f, 0.3f, 0.4f, 0.25f,

   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   0.309f, -0.25f, -0.95f, 0.3f, 0.4f, 0.25f,
   0.809f, -0.25f, -0.58f, 0.2f, 0.25f, 0.8f,

   0.809f, -0.25f, -0.58f, 0.2f, 0.25f, 0.8f,
   0.0f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f,
   1.0f, -0.25f, 0.0f, 1.0f, 0.0f, 0.0f,

   //squares

   1.0f, -0.25f, 0.0f, 1.0f, 0.0f, 0.0f,
   1.0f, +0.25f, 0.0f, 1.0f, 0.0f, 0.0f,
   0.809f, -0.25f, 0.58f, 0.0f, 0.0f, 1.0f,
   0.809f, -0.25f, 0.58f, 0.0f, 0.0f, 1.0f,
   0.809f, +0.25f, 0.58f, 0.0f, 0.0f, 1.0f,
   1.0f, +0.25f, 0.0f, 1.0f, 0.0f, 0.0f,

   0.809f, -0.25f, 0.58f, 0.0f, 0.0f, 1.0f,
   0.809f, +0.25f, 0.58f, 0.0f, 0.0f, 1.0f,
   0.309f, -0.25f, 0.95f, 1.0f, 1.0f, 0.0f,
   0.309f, -0.25f, 0.95f, 1.0f, 1.0f, 0.0f,
   0.309f, +0.25f, 0.95f, 1.0f, 1.0f, 0.0f,
   0.809f, +0.25f, 0.58f, 0.0f, 0.0f, 1.0f,

   0.309f, -0.25f, 0.95f, 1.0f, 1.0f, 0.0f,
   0.309f, +0.25f, 0.95f, 1.0f, 1.0f, 0.0f,
   -0.309f, -0.25f, 0.95f, 0.0f, 1.0f, 1.0f,
   -0.309f, -0.25f, 0.95f, 0.0f, 1.0f, 1.0f,
   -0.309f, +0.25f, 0.95f, 0.0f, 1.0f, 1.0f,
   0.309f, +0.25f, 0.95f, 1.0f, 1.0f, 0.0f,

   -0.309f, +0.25f, 0.95f, 0.0f, 1.0f, 1.0f,
   -0.309f, -0.25f, 0.95f, 0.0f, 1.0f, 1.0f,
   -0.809f, -0.25f, 0.58f, 0.25f, 0.4f, 0.7f,
   -0.809f, -0.25f, 0.58f, 0.25f, 0.4f, 0.7f,
   -0.809f, +0.25f, 0.58f, 0.25f, 0.4f, 0.7f,
   -0.309f, +0.25f, 0.95f, 0.0f, 1.0f, 1.0f,

    -0.809f, +0.25f, 0.58f, 0.25f, 0.4f, 0.7f,
     -0.809f, -0.25f, 0.58f, 0.25f, 0.4f, 0.7f,
     -1.0f, -0.25f, 0.0f, 0.0f, 0.25f, 0.25f,
     -1.0f, -0.25f, 0.0f, 0.0f, 0.25f, 0.25f,
     -1.0f, +0.25f, 0.0f, 0.0f, 0.25f, 0.25f,
   -0.809f, +0.25f, 0.58f, 0.25f, 0.4f, 0.7f,

      -1.0f, +0.25f, 0.0f, 0.0f, 0.25f, 0.25f,
     -1.0f, -0.25f, 0.0f, 0.0f, 0.25f, 0.25f,
     -0.809f, -0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
     -0.809f, -0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
     -0.809f, +0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
      -1.0f, +0.25f, 0.0f, 0.0f, 0.25f, 0.25f,

   -0.809f, +0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
   -0.809f, -0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
   -0.309f, -0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   -0.309f, -0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   -0.309f, +0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   -0.809f, +0.25f, -0.58f, 0.25f, 0.4f, 0.7f,

   -0.309f, +0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   -0.309f, -0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   0.309f, -0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   0.309f, -0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   0.309f, +0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   -0.309f, 0.25f, -0.95f, 0.0f, 1.0f, 1.0f,

   0.309f, +0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   0.309f, -0.25f, -0.95f, 0.0f, 1.0f, 1.0f,
   0.809f, -0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
   0.809f, -0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
   0.809f, +0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
   0.309f, +0.25f, -0.95f, 0.0f, 1.0f, 1.0f,

   0.809f, +0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
   0.809f, -0.25f, -0.58f, 0.25f, 0.4f, 0.7f,
   1.0f, -0.25f, 0.0f, 1.0f, 0.0f, 0.0f,
   1.0f, -0.25f, 0.0f, 1.0f, 0.0f, 0.0f,
   1.0f, +0.25f, 0.0f, 1.0f, 0.0f, 0.0f,
    0.809f, +0.25f, -0.58f, 0.25f, 0.4f, 0.7f,

};

   //  glm::vec3 cubePositions[] = {
   //    glm::vec3( 0.0f, 0.0f, 0.0f),
   //    glm::vec3( 2.0f, 5.0f, -15.0f),
   //    glm::vec3(-1.5f, -2.2f, -2.5f),
   //    glm::vec3(-3.8f, -2.0f, -12.3f),
   //    glm::vec3( 2.4f, -0.4f, -3.5f),
   //    glm::vec3(-1.7f, 3.0f, -7.5f),
   //    glm::vec3( 1.3f, -2.0f, -2.5f),
   //    glm::vec3( 1.5f, 2.0f, -2.5f),
   //    glm::vec3( 1.5f, 0.2f, -1.5f),
   //    glm::vec3(-1.3f, 1.0f, -1.5f)
   //    };

   // unsigned int indices[] = {
   //    0, 1, 3,
   //    1, 2, 3
   // };

   unsigned int VBO, VAO, EBO;
   glGenVertexArrays(1, &VAO);
   glGenBuffers(1, &VBO);
   glGenBuffers(1, &EBO);

   glBindVertexArray(VAO);

   glBindBuffer(GL_ARRAY_BUFFER, VBO);
   glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices,GL_STATIC_DRAW);

   // glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
   // glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

   glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)0);
   glEnableVertexAttribArray(0);

   glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)(3 * sizeof(float)));
   glEnableVertexAttribArray(1);

   // glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5*sizeof(float), (void*)(3 * sizeof(float)));
   // glEnableVertexAttribArray(1);

   unsigned int texture1, texture2;
   glGenTextures(1, &texture1);
   glBindTexture(GL_TEXTURE_2D, texture1);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

   int width, height, nrChannels;
   unsigned char *data = stbi_load("/home/pavani/Desktop/Graphics/Assignment0/source/wall.jpg", &width, &height, &nrChannels, 0);
   if(data!=NULL)
   {
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB,GL_UNSIGNED_BYTE, data);
      glGenerateMipmap(GL_TEXTURE_2D);
   }
   else
   {
      fprintf(stderr, "Unable to load texture 1 \n");
      return 0;
   }
   stbi_image_free(data);


   glGenTextures(1, &texture2);
   glBindTexture(GL_TEXTURE_2D, texture2);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

   stbi_set_flip_vertically_on_load(true);
   data = stbi_load("/home/pavani/Desktop/Graphics/Hello-World/source/awesomeface.png", &width, &height, &nrChannels, 0);
   if (data)
   {
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
      glGenerateMipmap(GL_TEXTURE_2D);
   }
   else
   {
      fprintf(stderr, "Unable to load texture 2 \n");
      return 0;
   }
   stbi_image_free(data);

   glClearColor(0.2f, 0.3f, 0.3f, 1.0f);

   glUseProgram(shaderProgram);
   
   glUniform1i(glGetUniformLocation(shaderProgram, "texture1"), 0);
   glUniform1i(glGetUniformLocation(shaderProgram, "texture2"),  1);
   
   // glm::mat4 view = glm::mat4(1.0f);
   // view = glm::translate(view, glm::vec3(0.0f, 0.0f, -3.0f));

   glm::mat4 projection;
   projection = glm::perspective(glm::radians(45.0f), 800.0f/600.0f, 0.1f, 100.0f);

   glEnable(GL_DEPTH_TEST);
  
   while (!glfwWindowShouldClose(window)) {
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      processInput(window);


      // const float radius = 10.0f;
      // float camX = sin(glfwGetTime()) * radius;
      // float camZ = cos(glfwGetTime()) * radius;
      glm::mat4 view;
      view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

      // glm::mat4 trans = glm::mat4(1.0f);
      // trans = glm::translate(trans, glm::vec3(0.5f, -0.5f, 0.0f));
      // trans = glm::rotate(trans, (float)glfwGetTime(), glm::vec3(0.0f, 0.0f, 1.0f));
      // unsigned int transformLoc = glGetUniformLocation(shaderProgram, "transform");
      // glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(trans));


      // glm::mat4 model = glm::mat4(1.0f);

      int viewLoc = glGetUniformLocation(shaderProgram, "view");
      glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));

      int projectionLoc = glGetUniformLocation(shaderProgram, "projection");
      glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));

      int modelLoc = glGetUniformLocation(shaderProgram, "model");

      glActiveTexture(GL_TEXTURE0);
      glBindTexture(GL_TEXTURE_2D, texture1);
      glActiveTexture(GL_TEXTURE1);
      glBindTexture(GL_TEXTURE_2D, texture2);

      glBindVertexArray(VAO);
      glm::mat4 model = glm::mat4(1.0f);
      model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
      model = glm::rotate(model, (float)glfwGetTime() * glm::radians(50.0f), glm::vec3(1.0f, 1.0f, 1.0f));


      glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
      glDrawArrays(GL_TRIANGLES, 0, 120);
      
      
      // glDrawArrays(GL_TRIANGLES, 0, 36);
      glfwSwapBuffers(window);
      glfwPollEvents();
   }

   glDeleteVertexArrays(1, &VAO);
   glDeleteBuffers(1, &VBO);
   glDeleteProgram(shaderProgram);

   glfwDestroyWindow(window);
   glfwTerminate();

   return 0;
}

